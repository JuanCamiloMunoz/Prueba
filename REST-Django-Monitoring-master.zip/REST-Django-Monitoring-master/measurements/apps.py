from django.apps import AppConfig


class MeasurementsConfig(AppConfig):
    name = 'measurements'

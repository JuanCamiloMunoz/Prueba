from django.apps import AppConfig


class MeasurementsnosqlConfig(AppConfig):
    name = 'measurementsNOSQL'
